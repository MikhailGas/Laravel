
<?php $__env->startSection('title', $news->title); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('menu.home_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-2">
        <img style="width:600px" src="<?php echo e($news->image ? $news->image : '/storage/default.jpg'); ?>" alt="Картинка">
    </div>
    <p><?php echo e($news->text); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\laravel-1\resources\views/news/oneNews.blade.php ENDPATH**/ ?>