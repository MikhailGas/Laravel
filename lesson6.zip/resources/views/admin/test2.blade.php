@extends('layouts.admin')
@section('title', 'Test2')

@section('content')
    <h1>Тест2</h1>
@endsection
