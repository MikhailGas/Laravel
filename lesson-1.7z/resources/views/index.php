<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная</title>
</head>
<body>
    <ul>
        <li><a href="/"><b>Главная</b></a></li>
        <li><a href="/about">О нас</a></li>
        <li><a href="/news">Новости</a></li>
        <li><a href="/contacts">Контакты</a></li>
    </ul>
    <h1>Главная</h1>
</body>
</html>