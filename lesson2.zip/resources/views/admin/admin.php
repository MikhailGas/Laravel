<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админка</title>
</head>
<body>
    <?php include 'menu.php';?> 
    <h1>Админка</h1>
    <ul>
        <li><a href=""></a></li>
        <li><a href=""></a></li>
        
    </ul>
</body>
</html>