<ul>
    <li><a href="<?=route('home')?>">Главная</a></li>
    <li><a href="/about">О нас</a></li>
    <li><a href="<?=route('news.categories')?>">Категории новостей</a></li>
    <li><a href="/contacts">Админка</a></li>
</ul>