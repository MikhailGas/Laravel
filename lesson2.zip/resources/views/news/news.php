<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новсти</title>
</head>
<body>
    <?php include 'menu.php';?>
    <h1>Новости</h1>
    <ul>
        <li><a href=""></a>Новость_1</li>
        <li><a href=""></a>Новость_2</li>
        <li><a href=""></a>Новость_3</li>
    </ul>      
</body>
</html>