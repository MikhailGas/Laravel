
<?php $__env->startSection('title', 'Категории новостей'); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('menu.home_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('news.category', [$category->slug])); ?>"><?php echo e($category->name . ' |'); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h2>Нет категорий</h2>

        <?php endif; ?>

    <hr>
    <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newsOne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <h2><?php echo e($newsOne->title); ?></h2>
        <div class="row mt-2">
            <a href="<?php echo e(route('news.newsOne', [$newsOne->id])); ?>">
                <img style="width:400px" src="<?php echo e($newsOne->image ? $newsOne->image : '/storage/default.jpg'); ?>" alt="Картинка">
            </a>
        </div>
        
        <a href="<?php echo e(route('news.newsOne', [$newsOne->id])); ?>">Подробнее...</a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h2>Нет новостей</h2>
    <?php endif; ?>
    <?php echo e($news->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\laravel-1\resources\views/news/categories.blade.php ENDPATH**/ ?>