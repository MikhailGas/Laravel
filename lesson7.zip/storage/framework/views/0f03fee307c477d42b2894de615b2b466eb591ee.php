
<?php $__env->startSection('title', 'Создать новость'); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('menu.admin_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form method="POST" action="<?php echo e(route('news.update' , $news->id)); ?>" class="mt-5" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group row">
            <label for="title" class="col-md-4 col-form-label text-md-right">Заголовок новости</label>

            <div class="col-md-6">
                <input id="title" type="text" class="form-control" name="title" value="<?php echo e($news->title); ?>" autofocus>
            </div>
        </div>

        <div class="form-group row">
            <label for="category_id" class="col-md-4 col-form-label text-md-right">Категория новости</label>

            <div class="col-md-6">
                <select name="category_id" id="category_id" class="form-control">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option <?php if($item->id == $news->category_id): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <option value="0">Нет категорий</option>
                    <?php endif; ?>
                    

                </select>
            </div>
        </div>

        <div class="form-group row">
            <label for="text" class="col-md-4 col-form-label text-md-right">Текст новости</label>

            <div class="col-md-6">
                <textarea id="text" class="form-control" name="text"><?php echo e($news->text); ?></textarea>
            </div>
        </div>

        <div class="form-group row">
            <div class="col-md-6 offset-md-4">
                <div class="form-check">
                    <input <?php if($news->isPrivate): ?> checked <?php endif; ?> class="form-check-input" type="checkbox" name="isPrivate" id="isPrivate" value="1" <?php echo e(old('isPrivate') ? 'checked' : ''); ?>>

                    <label class="form-check-label" for="isPrivate">
                        Приватная
                    </label>
                </div>
            </div>
        </div>

        <div class="form-group row">
            <label class="col-md-4 col-form-label text-md-right" for="image">
                Картинка для новости
            </label>
            <div class="col-md-6">
                <input type="file" name="image" id="image" value=<?php echo e($news->image); ?>>    
            </div>
           
        </div>

        <div class="form-group row mb-0">
            <div class="col-md-8 offset-md-4">
                <button type="submit" class="btn btn-primary">
                    Сохранить
                </button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\laravel-1\resources\views/admin/edit.blade.php ENDPATH**/ ?>