<a href="<?php echo e(route('home')); ?>">Главная</a>
<a href="<?php echo e(route('about')); ?>">О нас</a>
<a href="<?php echo e(route('news.categories')); ?>">Новости</a>
<a href="<?php echo e(route('admin.index')); ?>">Админка</a>
<?php /**PATH C:\OpenServer\OSPanel\domains\laravel-1\resources\views/home/menu.blade.php ENDPATH**/ ?>