<a href="<?php echo e(route('admin.test1')); ?>">test1</a>
<a href="<?php echo e(route('admin.test2')); ?>">test2</a>
<a href="<?php echo e(route('home')); ?>">Выход</a><?php /**PATH C:\OpenServer\OSPanel\domains\laravel-1\resources\views/menu/home-menu.blade.php ENDPATH**/ ?>