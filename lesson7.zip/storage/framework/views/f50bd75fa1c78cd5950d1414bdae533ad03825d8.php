
<?php $__env->startSection('title', 'Test2'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Тест2</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\laravel-1\resources\views/admin/test2.blade.php ENDPATH**/ ?>