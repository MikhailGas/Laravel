
<?php $__env->startSection('title', 'Админка'); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('menu.admin_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4 border shadow">
            <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <h4><a href="<?php echo e(route( 'news.show', $item->id)); ?>"><?php echo e($item->title); ?></a></h4>
                <div class="row">
                    <form class="ml-3" action="<?php echo e(route('news.destroy', $item->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="submit" value="Удалить" class="btn btn-primary">
                    </form>
                    <form class="ml-2" action="<?php echo e(route('news.edit', $item->id)); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <input type="submit" value="Редактировать" class="btn btn-primary">
                    </form>
                </div>
                
                
                
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                Нет новостей
            <?php endif; ?>
            <?php echo e($news->links()); ?>

        </div>
        <div class="col-md-8 border shadow">
            <?php if( isset( $newsOne) ): ?>
                <h1><?php echo e($newsOne->title); ?></h1>
                <div class="row mt-2">
                    <img class="ml-3" style="width:600px" src="<?php echo e($newsOne->image ? $newsOne->image : '/storage/default.jpg'); ?>" alt="Картинка">
                </div>
                <p><?php echo e($newsOne->text); ?></p>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel-1/resources/views/admin/index.blade.php ENDPATH**/ ?>