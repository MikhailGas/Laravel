<ul>
    <li><a href="<?php echo e(route('home')); ?>">Главная</a></li>
</ul><?php /**PATH C:\OpenServer\OSPanel\domains\laravel-1\resources\views/news/menu.blade.php ENDPATH**/ ?>